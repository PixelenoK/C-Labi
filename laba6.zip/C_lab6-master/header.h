#ifndef HEADER_H
#define HEADER_H

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <conio.h>
#include <locale.h>
#include <string.h>
#include <windows.h>
#define true 1
#define false 0
#define err -2000123000
#define maxEl 2147483646
double stod(char s[10000]);

#endif